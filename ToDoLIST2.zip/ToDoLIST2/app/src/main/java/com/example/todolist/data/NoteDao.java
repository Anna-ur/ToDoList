package com.example.todolist.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.OnConflictStrategy;
import androidx.room.Update;

import com.example.todolist.model.Note;

import java.util.List;

@Dao //аннотация для room, DataExesObject, методы надо сгенерировать
public interface NoteDao {

    //выборка
    @Query("SELECT * FROM Note") //запрос возвращает список всех
    List<Note> getAll();

    @Query("SELECT * FROM Note")
    LiveData<List<Note>> getAllLiveData();

    @Query("SELECT * FROM Note WHERE uid IN (:noteIds)") //загрузить все заметки у которых все id из списка
    List<Note> loadAllByIds(int[] noteIds);

    @Query("SELECT * FROM Note WHERE uid = :uid LIMIT 1") //выборка по id
    Note findById(int uid);

    //вставка
    @Insert(onConflict = OnConflictStrategy.REPLACE) //если id заметки существует - замена
    void insert(Note note);

    //обновление
    @Update
    void update(Note note);

    //удалние
    @Delete
    void delete(Note note);

}
