package com.example.todolist.screens.main;

import android.app.Activity;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SortedList;

import com.example.todolist.App;
import com.example.todolist.R;
import com.example.todolist.model.Note;
import com.example.todolist.screens.details.NoteDetailsActivity;

import java.util.List;


public class Adapter extends RecyclerView.Adapter<Adapter.NoteViewHolder> {


    private SortedList<Note> sortedList;

    public Adapter(){
        sortedList = new SortedList<>(Note.class, new SortedList.Callback<Note>() {

            //сравнивает два объекта
            @Override
            public int compare(Note o1, Note o2) {
                if (!o2.done && o1.done){
                    return 1;
                }
                if (o2.done && !o1.done){
                    return -1;
                }
                return (int) (o2.timestamp - o1.timestamp);
            }

            //обновение отдельных элементов
            @Override
            public void onChanged(int position, int count) {
                notifyItemRangeChanged(position, count);
            }

            // если содержимое двух элементов одинаковое
            @Override
            public boolean areContentsTheSame(Note oldItem, Note newItem) {
                return oldItem.equals(newItem);
            }

            //одинаковые id
            @Override
            public boolean areItemsTheSame(Note item1, Note item2) {
                return item1.uid == item2.uid;
            }

            //ф-ии об изменениях
            @Override
            public void onInserted(int position, int count) {
                notifyItemRangeInserted(position, count);
            }

            @Override
            public void onRemoved(int position, int count) {
                notifyItemRangeRemoved(position, count);
            }

            @Override
            public void onMoved(int fromPosition, int toPosition) {
                notifyItemMoved(fromPosition, toPosition);
            }
        });
    }


    //создание нового ViewHolder
    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new NoteViewHolder(
                LayoutInflater.from(parent.getContext()).inflate(R.layout.item_note_list, parent, false)
        );
    }

    //привязка конкретной заметки к ViewHolder
    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        holder.bind(sortedList.get(position));
    }

    //размер = количеству
    @Override
    public int getItemCount() {
        return sortedList.size();
    }

    //обновление списка содержимого адаптера
    public void setItems(List<Note> notes){
        sortedList.replaceAll(notes);
    }


    // класс для отдельного элемента
    static class NoteViewHolder extends RecyclerView.ViewHolder{

        TextView noteText;
        CheckBox completed;
        View delete;

        Note note;//заметка, которая отображается в данный момент

        boolean silentUpdate;

        //конструктор
        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);

            noteText = itemView.findViewById(R.id.note_text);
            completed = itemView.findViewById(R.id.completed);
            delete = itemView.findViewById(R.id.delete);

            //для редактирования заметки
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    NoteDetailsActivity.start((Activity)itemView.getContext(), note);
                }
            });

            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    App.getInstance().getNoteDao().delete(note);
                }
            });

            //обработчик
            completed.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged( CompoundButton compoundButton, boolean checked) {
                    if (!silentUpdate){ //если выполнена
                        note.done = checked; //обновление заметки
                        App.getInstance().getNoteDao().update(note);//сохранение измений
                    }
                    updateStrokeOut();//обновление зачёркивания
                }
            });
        }

        //значение полей заметки на внешние view
        public void bind(Note note){
            this.note = note;

            noteText.setText(note.text);
            updateStrokeOut();

            //выполненное/не выполненное
            silentUpdate = true;
            completed.setChecked(note.done);
            silentUpdate = false;

        }

        //зачёркивание выполненного
        private void updateStrokeOut(){
            if (note.done){
                noteText.setPaintFlags(noteText.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);//побитовое или
            }
            else{
                noteText.setPaintFlags(noteText.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);//побитовое и
            }
        }
    }
}
