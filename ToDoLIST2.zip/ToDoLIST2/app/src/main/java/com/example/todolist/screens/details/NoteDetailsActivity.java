package com.example.todolist.screens.details;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.todolist.App;
import com.example.todolist.R;
import com.example.todolist.model.Note;

public class NoteDetailsActivity extends AppCompatActivity { //библиотека совместимостей
    private static final String EXTRA_NOTE = "NoteDetailsActivity.EXTRA_NOTE"; //передача всей заметки
    private Note note;//сама заметка
    private EditText editText;
    //вызов одного активити из другого
    public static void start(Activity caller, Note note){
        Intent intent = new Intent(caller, NoteDetailsActivity.class);
        if (note != null) {
            intent.putExtra(EXTRA_NOTE, note);
        }
        caller.startActivity(intent);
    }

 //функция при создании активити
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_note_details);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);//как actionbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//кнопка назад
        getSupportActionBar().setHomeButtonEnabled(true);

        setTitle(getString(R.string.note_details_title));

        editText = findViewById(R.id.text);

        //написание заметки
        //если заметка не пуста
        if (getIntent().hasExtra(EXTRA_NOTE)){
            note = getIntent().getParcelableExtra(EXTRA_NOTE);
            editText.setText(note.text);
        }else{
            note = new Note();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_details, menu);//откуда-куда
        return super.onCreateOptionsMenu(menu);
    }

    //обработка для событий выхода/сохранения
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
            case R.id.action_save:
                if (editText.getText().length() > 0){
                    note.text = editText.getText().toString();//текст заметки
                    note.done = false; //дело не отмечено как выполненное
                    note.timestamp = System.currentTimeMillis();
                    if (getIntent().hasExtra(EXTRA_NOTE)){ //если старая заемтка
                        App.getInstance().getNoteDao().update(note);
                    }else {
                        App.getInstance().getNoteDao().insert(note);
                    }
                    finish();
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
